Super Mario Advance 4 — Reusable Save & Quit universal patcher

Open the HTML file in Chrome/Edge/Firefox, select an unmodified supported GBA ROM, and click Patch and download ROM. All processing is offline.

Versions: 
USA (original): SHA1 69e81f41394f02d64cad206adb26b3cd43690770, ORR offset 0x3AE96
USA / Australia (Rev 1): SHA1 532f3307021637474b6dd37da059ca360f612337, ORR offset 0x3B222
Europe (original): SHA1 b7f3d6dc014e2f0ddc996137bdefbb8167a77e66, ORR offset 0x3C9BE
Europe (Rev 1): SHA1 2e5ce11a893464dc0cce0a6b451580ba35a7e5de, ORR offset 0x3CCDE
Europe (Rev 1, Wii U Virtual Console): SHA1 00667ce3da4bfee3182c4445ac2f5483870be97c, ORR offset 0x3CCDE

The patch changes the Thumb ORR opcode 08 43 to C0 46. Only European Wii U was confirmed by user gameplay; other builds pass matching-code and hash checks, not gameplay tests. Does not implement batteryless saving.
